#!/bin/sh
poweroff
